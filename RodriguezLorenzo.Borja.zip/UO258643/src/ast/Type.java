/**
 * @generated VGen (for ANTLR) 1.6.0
 */

package ast;

public interface Type extends AST {
    public int getMemorySize();

    char getSuffix();

    String getMAPLName();
}
