/**
 * @generated VGen (for ANTLR) 1.7.0
 */

package ast;

public abstract class AbstractType extends AbstractAST implements Type {
    @Override
	public String getMAPLName() {
		return "";
	}

	@Override
	public char getSuffix() {
		return ' ';
	}
}
