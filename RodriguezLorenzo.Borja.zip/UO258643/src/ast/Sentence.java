/**
 * @generated VGen (for ANTLR) 1.7.0
 */

package ast;

public interface Sentence extends AST {

}
